

<!DOCTYPE html>
<html lang="en">
<head>

  <title>Maggie Maylin</title>
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/slick-theme.css">
  <link rel="stylesheet" href="css/slick.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <span class="navbar-text">Maggie Maylin Dashboard</span>
</nav>


<?php include("include/index_main.inc") ?>


<div class="abtme pb-4">
<div class="container">
  <h1>About me</h1>
  <div class="card-group " >
      <div class="card">
        <div class="container custom-file m-auto">
          <input type="file" id="myfile" class="custom-file-input">
          <label class="custom-file-label" for="myfile">Choose file</label>
        </div>
      </div>
      <div class="card">
          <div class="card-body">

                <h4 class="card-title">
                  <input class="form-control" name="title" type="text" placeholder="Enter Card Title" value="">
                </h4>
                <p class="card-text">
                  <textarea class="form-control" name="name" rows="8" cols="80" placeholder="Enter Card Text"></textarea>
                </p>
                <input class="btn btn-primary"type="submit" value="Submit form">

          </div>
      </div>
  </div>
</div>
</div>

<section id="showcase" class="py-5">
    <div class="container">
      <div class="card-group">
          <div class="card" >
            <div class="container custom-file m-auto">
              <input type="file" id="myfile" class="custom-file-input">
              <label class="custom-file-label" for="myfile">Choose file</label>
            </div>

          </div>
          <div class="card" >
            <div class="container custom-file m-auto">
              <input type="file" id="myfile" class="custom-file-input">
              <label class="custom-file-label" for="myfile">Choose file</label>
            </div>

          </div>
          <div class="card" >
            <div class="container custom-file m-auto">
              <input type="file" id="myfile" class="custom-file-input">
              <label class="custom-file-label" for="myfile">Choose file</label>
            </div>

          </div>
      </div>
  </div>
</section>

<section class="second text-white ">
  <div class="container">
    <h2 class="text-center">News and Articles</h2>
    <div class="row">
      <div class="col">
        <div class="slider">
          <div>
            <p class="card-text">
              <textarea class="form-control" name="name" rows="8" cols="80" placeholder="Enter Card Text"></textarea>
            </p>
            <input class="btn btn-primary"type="submit" value="Submit form">
          </div>
          <div>
            <p class="card-text">
              <textarea class="form-control" name="name" rows="8" cols="80" placeholder="Enter Card Text"></textarea>
            </p>
            <input class="btn btn-primary"type="submit" value="Submit form">
          </div>
          <div>
            <p class="card-text">
              <textarea class="form-control" name="name" rows="8" cols="80" placeholder="Enter Card Text"></textarea>
            </p>
            <input class="btn btn-primary"type="submit" value="Submit form">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</body>
<script src="js/jquery.admin.js"></script>
<script src="js/jquery.min.js" ></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/btn.js"></script>
<script src="js/slick.js"></script>
<script src="js/main.js"></script>
</html>
